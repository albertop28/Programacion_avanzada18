﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO.Ports; 

namespace Arduino_Led
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            if(!serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Open();
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void button_Encender_Click(object sender, EventArgs e)
        {
            byte[] mBuffer = Encoding.ASCII.GetBytes("Led_ON");
            serialPort1.Write(mBuffer, 0, mBuffer.Length);
        }

        private void button_Apagar_Click(object sender, EventArgs e)
        {
            byte[] mBuffer = Encoding.ASCII.GetBytes("Led_OFF");
            serialPort1.Write(mBuffer, 0, mBuffer.Length);
        }

        private void label1_Click(object sender, EventArgs e)
        {


        }
    }
}
