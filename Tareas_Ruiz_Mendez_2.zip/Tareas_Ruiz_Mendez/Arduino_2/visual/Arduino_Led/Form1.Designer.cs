﻿namespace Arduino_Led
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_Encender = new System.Windows.Forms.Button();
            this.button_Apagar = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // button_Encender
            // 
            this.button_Encender.Location = new System.Drawing.Point(100, 89);
            this.button_Encender.Name = "button_Encender";
            this.button_Encender.Size = new System.Drawing.Size(75, 43);
            this.button_Encender.TabIndex = 0;
            this.button_Encender.Text = "Recibir entrada";
            this.button_Encender.UseVisualStyleBackColor = true;
            this.button_Encender.Click += new System.EventHandler(this.button_Encender_Click);
            // 
            // button_Apagar
            // 
            this.button_Apagar.Location = new System.Drawing.Point(100, 147);
            this.button_Apagar.Name = "button_Apagar";
            this.button_Apagar.Size = new System.Drawing.Size(75, 43);
            this.button_Apagar.TabIndex = 1;
            this.button_Apagar.Text = "Apagar";
            this.button_Apagar.UseVisualStyleBackColor = true;
            this.button_Apagar.Click += new System.EventHandler(this.button_Apagar_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.PortName = "COM4";
            this.serialPort1.StopBits = System.IO.Ports.StopBits.Two;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.button_Apagar);
            this.Controls.Add(this.button_Encender);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electrónica PIC - C# 2015";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Encender;
        private System.Windows.Forms.Button button_Apagar;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

